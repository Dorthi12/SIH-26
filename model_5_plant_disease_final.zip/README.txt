MODEL 5 — PLANT DISEASE DETECTION
=================================

Architecture:
EfficientNet-B0

Dataset:
PlantVillage

Classes:
38

Input:
224 x 224 RGB

Training:
ImageNet pretrained EfficientNet-B0
with partial backbone fine-tuning.

VALIDATION
----------
Macro F1:
0.9693

FINAL TEST
----------

Test images:
10,861

Accuracy:
97.4312%

Macro Precision:
96.9600%

Macro Recall:
96.6600%

Macro F1:
96.7500%

Weighted F1:
97.4300%

Correct:
10,582

Incorrect:
279

Error rate:
2.5688%

IMPORTANT
---------
This is a closed-set 38-class PlantVillage classifier.

It should not be treated as a universal plant disease
diagnostic system.

Production inference should include:
- image validation
- confidence handling
- probability calibration
- uncertainty rejection
- appropriate user messaging