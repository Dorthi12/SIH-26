"""
Server-side derivation of the 4 features CatBoost expects that are NOT
collected directly from the API caller:

    log_area                 <- area
    district_crop_cv_area    <- district_crop_std_area, district_crop_mean_area
    area_vs_recent_3yr_mean  <- area, recent_3yr_area_mean
    area_vs_recent_5yr_mean  <- area, recent_5yr_area_mean

⚠️ UNVERIFIED AGAINST TRAINING CODE — READ BEFORE RELYING ON THIS IN PRODUCTION

Everything in this file is my best-guess reconstruction from the field names
alone (`model_3_v3_feature_schema.json` gives names, not formulas). It has
NOT been checked against the actual training/feature-engineering notebook
that produced `model_3_v3_catboost.cbm`. Two things in particular could be
wrong and would silently skew predictions if so:

  1. log_area might be log1p(area) — used here — or log(area), or
     log1p(area * some_unit_conversion). Confirm against training code.

  2. Zero-denominator behavior (mean_area == 0, recent_Nyr_area_mean == 0)
     is currently handled with the fallback defaults below. Training code
     may have used a different convention (e.g. NaN, a sentinel value, or
     an entirely separate "has_history" flag feature). Confirm this too.

This is deliberately isolated in its own module — a single place to edit —
so that once you've confirmed (or corrected) the formulas against the
training pipeline, you only need to change this file, not go hunting
through model_service.py.

Every time a zero-denominator fallback actually fires, it's logged at
WARNING level below, so you can grep production logs to see how often this
edge case is actually hit and whether it matters in practice.
"""

import logging

import numpy as np

logger = logging.getLogger("model_3_v3.feature_derivation")

# Fallback values used when a ratio's denominator is exactly 0.
# UNVERIFIED against training — see module docstring.
CV_AREA_ZERO_MEAN_DEFAULT = 0.0
AREA_VS_MEAN_ZERO_MEAN_DEFAULT = 1.0


def _safe_ratio(numerator: float, denominator: float, default: float, feature_name: str) -> float:
    if denominator == 0:
        logger.warning(
            "%s: zero denominator (numerator=%s) — using fallback default=%s. "
            "This fallback is unverified against training; see feature_derivation.py.",
            feature_name, numerator, default,
        )
        return default
    return numerator / denominator


def derive_log_area(area: float) -> float:
    """UNVERIFIED formula: log1p(area). Confirm against training code."""
    return float(np.log1p(area))


def derive_district_crop_cv_area(district_crop_std_area: float, district_crop_mean_area: float) -> float:
    """UNVERIFIED formula: std_area / mean_area, 0.0 if mean_area == 0."""
    return _safe_ratio(
        district_crop_std_area, district_crop_mean_area,
        default=CV_AREA_ZERO_MEAN_DEFAULT, feature_name="district_crop_cv_area",
    )


def derive_area_vs_recent_3yr_mean(area: float, recent_3yr_area_mean: float) -> float:
    """UNVERIFIED formula: area / recent_3yr_area_mean, 1.0 if mean == 0."""
    return _safe_ratio(
        area, recent_3yr_area_mean,
        default=AREA_VS_MEAN_ZERO_MEAN_DEFAULT, feature_name="area_vs_recent_3yr_mean",
    )


def derive_area_vs_recent_5yr_mean(area: float, recent_5yr_area_mean: float) -> float:
    """UNVERIFIED formula: area / recent_5yr_area_mean, 1.0 if mean == 0."""
    return _safe_ratio(
        area, recent_5yr_area_mean,
        default=AREA_VS_MEAN_ZERO_MEAN_DEFAULT, feature_name="area_vs_recent_5yr_mean",
    )


def derive_all(row: dict) -> dict:
    """Takes a validated request's field dict, returns it with the 4 derived features added."""
    row = dict(row)
    row["log_area"] = derive_log_area(row["area"])
    row["district_crop_cv_area"] = derive_district_crop_cv_area(
        row["district_crop_std_area"], row["district_crop_mean_area"]
    )
    row["area_vs_recent_3yr_mean"] = derive_area_vs_recent_3yr_mean(row["area"], row["recent_3yr_area_mean"])
    row["area_vs_recent_5yr_mean"] = derive_area_vs_recent_5yr_mean(row["area"], row["recent_5yr_area_mean"])
    return row
