"""
Loads the CatBoost classifier + isotonic calibrator once at startup and
exposes a simple predict interface used by the FastAPI routes.

STATUS (round 2 review):
- 4 derived features (log_area, district_crop_cv_area, area_vs_recent_3yr_mean,
  area_vs_recent_5yr_mean) are computed HERE from the base fields instead of
  being trusted from the client. The formulas themselves now live in
  feature_derivation.py and are explicitly marked UNVERIFIED against the
  training pipeline — read that file before trusting this in production.
- THRESHOLD_APPLIES_TO (env var, default "calibrated") controls whether
  zero_production_flag compares the threshold against the calibrated or the
  raw probability. The schema field is literally named
  "raw_classification_threshold", which is ambiguous, and CANNOT be resolved
  from the artifact alone — no amount of statistical reasoning about Brier
  scores tells you which probability scale 0.9 was selected on. This is NOT
  a "default that's probably fine" — it is an unresolved unknown. Do not
  ship to production without checking the training/evaluation code for the
  line that actually applied this threshold.
- Risk bands and model_version are added for response enrichment.
- request_id is generated per call (or accepted from the caller) for tracing.
"""

import logging
import os
import uuid
from pathlib import Path
from functools import lru_cache

import joblib
import pandas as pd
from catboost import CatBoostClassifier

from app.schemas import ZeroProductionRequest, ZeroProductionResponse, BatchResultItem
from app.feature_derivation import derive_all

logger = logging.getLogger("model_3_v3")

ARTIFACT_DIR = Path(__file__).parent
MODEL_PATH = ARTIFACT_DIR / "model_3_v3_catboost.cbm"
CALIBRATOR_PATH = ARTIFACT_DIR / "model_3_v3_isotonic_calibrator.joblib"
SCHEMA_PATH = ARTIFACT_DIR / "model_3_v3_feature_schema.json"

# Artifact/model version — not present in feature_schema.json, so tracked
# explicitly here. Distinct from API_VERSION in routes.py (that's the API's
# own version, this is the trained-model's version).
MODEL_VERSION = "3.0.0"

# "calibrated" or "raw" — UNRESOLVED, see module docstring above.
# Must be confirmed against training/eval code before production use.
THRESHOLD_APPLIES_TO = os.environ.get("THRESHOLD_APPLIES_TO", "calibrated").lower()
if THRESHOLD_APPLIES_TO not in ("calibrated", "raw"):
    raise ValueError('THRESHOLD_APPLIES_TO must be "calibrated" or "raw"')


def _risk_level(calibrated_prob: float) -> str:
    """Product-level interpretation band — not a validated risk category."""
    if calibrated_prob < 0.20:
        return "LOW"
    if calibrated_prob < 0.50:
        return "MODERATE"
    if calibrated_prob < 0.75:
        return "HIGH"
    if calibrated_prob < 0.90:
        return "VERY_HIGH"
    return "CRITICAL"


class ZeroProductionModel:
    """Wraps the raw CatBoost model and its isotonic calibrator."""

    def __init__(self):
        import json

        with open(SCHEMA_PATH, "r") as f:
            self.schema: dict = json.load(f)

        self.feature_order: list[str] = self.schema["features"]
        self.categorical_features: list[str] = self.schema["categorical_features"]
        self.threshold: float = self.schema["raw_classification_threshold"]
        self.threshold_applies_to: str = THRESHOLD_APPLIES_TO
        self.model_version: str = MODEL_VERSION

        logger.info("Loading CatBoost model from %s", MODEL_PATH)
        self.model = CatBoostClassifier()
        self.model.load_model(str(MODEL_PATH))

        logger.info("Loading isotonic calibrator from %s", CALIBRATOR_PATH)
        self.calibrator = joblib.load(CALIBRATOR_PATH)

        # sanity check: model's own feature names (if present) line up with schema
        model_features = list(getattr(self.model, "feature_names_", []) or [])
        if model_features and model_features != self.feature_order:
            logger.warning(
                "Model's internal feature order differs from schema file; "
                "using the model's own order for inference to stay safe."
            )
            self.feature_order = model_features

        logger.info(
            "Model 3 V3 ready — threshold=%.3f applies_to=%s model_version=%s",
            self.threshold, self.threshold_applies_to, self.model_version,
        )

    def _enrich(self, record: ZeroProductionRequest) -> dict:
        """Adds the 4 derived features — formulas live in feature_derivation.py (unverified against training)."""
        return derive_all(record.model_dump())

    def _to_frame(self, row: dict) -> pd.DataFrame:
        ordered = {col: row[col] for col in self.feature_order}
        df = pd.DataFrame([ordered])
        for col in self.categorical_features:
            df[col] = df[col].astype(str)
        return df

    def _decide(self, raw_prob: float, calibrated_prob: float) -> tuple[bool, str]:
        decision_prob = calibrated_prob if self.threshold_applies_to == "calibrated" else raw_prob
        return decision_prob >= self.threshold, _risk_level(calibrated_prob)

    def predict_one(self, record: ZeroProductionRequest, request_id: str | None = None) -> ZeroProductionResponse:
        row = self._enrich(record)
        df = self._to_frame(row)
        raw_prob = float(self.model.predict_proba(df)[:, 1][0])
        calibrated_prob = float(self.calibrator.predict([raw_prob])[0])
        flag, risk_level = self._decide(raw_prob, calibrated_prob)

        return ZeroProductionResponse(
            request_id=request_id or str(uuid.uuid4()),
            model_version=self.model_version,
            raw_probability=raw_prob,
            calibrated_probability=calibrated_prob,
            zero_production_flag=flag,
            threshold_used=self.threshold,
            threshold_applies_to=self.threshold_applies_to,
            risk_level=risk_level,
        )

    def predict_batch(
        self, records: list[ZeroProductionRequest], request_id: str | None = None
    ) -> list[BatchResultItem]:
        if not records:
            return []

        rows = [self._enrich(r) for r in records]
        ordered_rows = [{col: row[col] for col in self.feature_order} for row in rows]
        df = pd.DataFrame(ordered_rows)
        for col in self.categorical_features:
            df[col] = df[col].astype(str)

        raw_probs = self.model.predict_proba(df)[:, 1]
        calibrated_probs = self.calibrator.predict(raw_probs)

        results = []
        for i, (rp, cp) in enumerate(zip(raw_probs, calibrated_probs)):
            flag, risk_level = self._decide(float(rp), float(cp))
            results.append(
                BatchResultItem(
                    index=i,
                    request_id=request_id or str(uuid.uuid4()),
                    model_version=self.model_version,
                    raw_probability=float(rp),
                    calibrated_probability=float(cp),
                    zero_production_flag=flag,
                    threshold_used=self.threshold,
                    threshold_applies_to=self.threshold_applies_to,
                    risk_level=risk_level,
                )
            )
        return results


@lru_cache(maxsize=1)
def get_model() -> ZeroProductionModel:
    """Cached singleton — model + calibrator are loaded from disk only once."""
    return ZeroProductionModel()
