# Model 3 V3 — Zero-Production Risk API (corrected, round 2)

FastAPI service wrapping `model_3_v3_catboost.cbm` (CatBoostClassifier) +
`model_3_v3_isotonic_calibrator.joblib` (sklearn IsotonicRegression).

## Structure
```
main.py
app/
  routes.py                                # endpoints, see below
  model_service.py                         # loads model+calibrator, derives features, decides
  schemas.py                               # Pydantic request/response models + validation
  model_3_v3_catboost.cbm
  model_3_v3_isotonic_calibrator.joblib
  model_3_v3_feature_schema.json
requirements.txt
```

## Run it
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```
Docs at `http://localhost:8000/docs`.

## Round 2 fixes (this delivery)

| # | Fix | What / why |
|---|---|---|
| 1 | 🔴 sklearn pin | `requirements.txt` now pins `scikit-learn==1.6.1` — the *exact* version the `.joblib` calibrator was serialized with (confirmed via the `InconsistentVersionWarning` it threw under 1.8.0). Verified: reinstalling 1.6.1 and reloading the calibrator produces **zero** warnings. `>=1.6` was too loose for a pickled sklearn estimator in a production service. |
| 2 | 🟠 Derived-feature formulas isolated | Moved to a new `app/feature_derivation.py`, and every function there is explicitly labeled **UNVERIFIED against the training pipeline** — I can tell you the formulas are internally consistent, I cannot tell you they match what training actually did, because that code wasn't in the artifacts I have. One file to check/edit once you find the real formulas. |
| 3 | 🟠 Zero-denominator defaults made observable | Each fallback (`mean_area==0`, `recent_Nyr_area_mean==0`) now logs a `WARNING` with the feature name and the value used, so you can grep production logs to see how often this edge case actually fires — verified by triggering it in testing. |
| 4 | 🔴→still ⚠️ Threshold semantics | **Not resolved** — it can't be, from the artifact alone. `THRESHOLD_APPLIES_TO` remains configurable (default `calibrated`), but the docstrings and code comments no longer imply that's a safe default — they now say explicitly this is an unverified guess that must be checked against training/eval code before production use. |
| 5 | 🟡 Batch size via schema | `records: List[...] = Field(..., min_length=1, max_length=5000)` replaces the manual length checks in the route — verified an empty batch now gets a `422` automatically. |
| 6 | 🟡 Version naming | `model_version` is now `"3.0.0"` (an artifact version) instead of the slug `"model-3-v3"`, kept distinct from `api_version` (`"1.2.0"`) in `/version` and `/info`. |
| 7 | 🟡 `/predict` docstring softened | No longer implies "calibrated is the right choice" — states plainly that the threshold target is this service's current configuration, not a validated recommendation. |

**Still explicitly unresolved (cannot be fixed without your training code/data):**
- Whether `0.9` applies to raw or calibrated probability
- Whether the 4 derived-feature formulas exactly match training
- Whether the zero-denominator fallback values match training's convention

I'm not marking these "done" because I can't verify them from what's in the model artifacts — doing so would just be asserting a guess with more confidence than it deserves. They're isolated into as few places as possible (one env var, one file) so resolving them is a small edit once you have the answer, not a redesign.

## What changed from the first version

| # | Correction | Where |
|---|---|---|
| 1 | Threshold semantics made explicit + configurable (`THRESHOLD_APPLIES_TO` env var, default `calibrated`) — **you still need to verify how 0.9 was actually selected during training**, this only stops the code from being silently wrong either way | `model_service.py` |
| 2 | `/predict` response now includes `risk_level` (LOW/MODERATE/HIGH/VERY_HIGH/CRITICAL), documented as a product-level band, not a validated category | `schemas.py`, `model_service.py` |
| 3 | `model_version` added to every response and to a new `/version` endpoint | `model_service.py`, `routes.py` |
| 4 | `request_id`: accepted via `X-Request-ID` header (falls back to a generated UUID) and echoed in every response, including each batch item | `routes.py`, `model_service.py` |
| 5–6 | Field validation: rates constrained to `[0,1]`, counts to `>=0`, `area` to `>0`, yield/area magnitudes to `>=0` | `schemas.py` |
| 7 | `log_area`, `district_crop_cv_area`, `area_vs_recent_3yr_mean`, `area_vs_recent_5yr_mean` are **no longer accepted from the client** — they're computed server-side from the base fields, so they can't contradict them | `schemas.py`, `model_service.py` |
| 8–9 | Documented (not fabricated): a real `/predict/from-context` endpoint that turns `{state, district, crop, season, area, prediction_year}` into the other ~30 historical features needs a time-aware feature store/DB query (`year < prediction_year`, to avoid leakage). That data isn't part of these model artifacts, so a stub is included that explains the contract and returns `501` rather than silently faking it | `routes.py` |
| 10 | `/info` expanded with `model_version`, `calibration`, `threshold_applies_to` | `routes.py` |
| 11 | Split `/health` (fast liveness, no model touch) from `/ready` (model + calibrator load check) | `routes.py` |
| 12 | `/version` endpoint added | `routes.py` |
| 13 | Batch results now include `index` so each result maps unambiguously back to its input record | `schemas.py`, `model_service.py` |
| 14 | Raw exception text is no longer returned to callers — only logged server-side. Set `DEBUG_MODE=1` to get it back in responses during development | `routes.py` |
| 15 | Categorical fields (`state`, `district`, `crop`, `season`) are stripped of surrounding whitespace. Case is **left untouched on purpose** — don't lowercase unless you've confirmed the training vocabulary was lowercased | `schemas.py` |
| 16 | Category-vocabulary validation (e.g. "Unknown crop: XYZ") was **not** added — the feature schema JSON doesn't include the trained category vocabulary, so there's nothing to validate against yet. If you export that list, it's a small addition to `schemas.py` | — |

All of the above were re-tested end-to-end against your actual `.cbm` and `.joblib` files (health, ready, version, info, predict, batch, all three validation-rejection cases, and the from-context stub) before packaging.

## Endpoints (mounted under `/api/v1/model-3-v3`)
- `GET /health` — liveness only
- `GET /ready` — model + calibrator loaded
- `GET /version` — API + model version
- `GET /info` — metadata, metrics, threshold info
- `POST /predict` — single record → raw + calibrated probability, flag, risk_level
- `POST /predict/batch` — up to 5000 records, each result indexed
- `POST /predict/from-context` — documented stub, returns `501` until wired to a historical feature store

## Still open (can't be done from the model artifacts alone)
- **Threshold verification (P0)**: confirm with whoever trained the model whether 0.9 was chosen on raw or calibrated probabilities, then set `THRESHOLD_APPLIES_TO` accordingly (or leave the default if it's already calibrated).
- **Time-aware feature builder**: implementing `/predict/from-context` for real requires your historical yield database and a query pattern that only uses `year < prediction_year`.
- **Category vocabulary validation**: needs the list of categories seen during training (not present in `feature_schema.json`).
- **Auth / rate limiting**: intentionally left to your API gateway / backend, not this service.

## If merging into an existing FastAPI app
```python
from app.routes import router as model_3_v3_router
app.include_router(model_3_v3_router, prefix="/api/v1/model-3-v3", tags=["model-3-v3"])
```
Keep the three model artifact files alongside `model_service.py`, or update `ARTIFACT_DIR` in that file.
